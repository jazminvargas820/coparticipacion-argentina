from importlib.resources import files


def display_menu():
    programs_folder = files("poppins.programs")

    program_files = sorted(
        [
            file
            for file in programs_folder.iterdir()
            if file.name.lower().endswith(".txt")
        ],
        key=lambda x: x.name.lower()
    )

    if not program_files:
        print("No programs found.")
        return

    while True:
        print("\n" + "=" * 50)
        print("                 POPPINS")
        print("=" * 50)

        for number, program in enumerate(program_files, start=1):
            print(f"{number}. {program.name}")

        print("0. Exit")
        print("=" * 50)

        choice = input("Enter your choice: ")

        if choice == "0":
            print("Goodbye!")
            break

        try:
            choice = int(choice)

            if 1 <= choice <= len(program_files):
                selected_program = program_files[choice - 1]

                print("\n" + "=" * 70)
                print(f"PROGRAM: {selected_program.name}")
                print("=" * 70)

                content = selected_program.read_text(encoding="utf-8")
                print(content)

                print("=" * 70)
                input("\nPress Enter to return to the menu...")

            else:
                print("Invalid choice.")

        except ValueError:
            print("Please enter a number.")


def main():
    display_menu()


if __name__ == "__main__":
    main()